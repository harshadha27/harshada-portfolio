# Harshada Jadhav — Developer Portfolio

React 18 + TypeScript + Tailwind CSS 3 + Vite.

## Run locally
```bash
npm install
npm run dev        # http://localhost:5173
```

## Build for production
```bash
npm run build      # outputs to dist/
npm run preview
```

Deploy the `dist/` folder to Netlify, Vercel, GitHub Pages or any static host.

## Editing content
All text lives at the top of `src/App.tsx` (`PROJECTS`, `JOBS`, `SKILLS`, `CERTS`, `WINS`, `LINKS`).
Colour palettes are in `PALETTES` in the same file. Resume PDFs and the photo are in `public/`.
