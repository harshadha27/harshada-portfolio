import { useState, useEffect, useRef, type ReactNode } from "react";

const BASE = import.meta.env.BASE_URL;
const PHOTO = BASE + "profile_pic.jpg";
const PDFS = { general: "Harshada_Jadhav_Resume.pdf", salesforce: "Harshada_Jadhav_Salesforce_Resume.pdf" } as const;
const LINKS = {
  github: "https://github.com/harshadha27",
  linkedin: "https://linkedin.com/in/harshada-jadhav",
  youtube: "https://www.youtube.com/@harshada_jadhav__27",
  email: "harshadajadhav442@gmail.com",
  phone: "+91-9421853525",
};

interface Project { title: string; cat: "AI" | "Salesforce" | "Robotics"; tech: string[]; summary: string; points: string[]; link: string; }
interface Job { role: string; org: string; place: string; when: string; points: string[]; }

const PROJECTS: Project[] = [
  { title: "FaultFusion", cat: "AI", tech: ["React.js", "TypeScript", "Vite", "LLM Integration", "AI Agents"],
    summary: "AI-powered multi-agent debugging platform that analyzes code and recommends fixes.",
    points: ["Multi-agent architecture using AI agents and LLM integration to analyze code and suggest fixes.", "React.js and TypeScript interface built with Vite.", "Ongoing project since 2024."],
    link: "https://github.com/harshadha27/FaultFusion" },
  { title: "GenAI Written Assessment System", cat: "AI", tech: ["Python", "Flask", "Gemini 1.5 Flash", "NLTK", "Firebase Firestore", "Google OAuth 2.0"],
    summary: "AI-powered essay evaluation with NLP-based semantic, stylistic and pragmatic assessment.",
    points: ["Generative AI system backed by a cloud database (Firebase Firestore).", "Secure sign-in with Google OAuth 2.0.", "NLP evaluation across semantic, stylistic and pragmatic dimensions."],
    link: LINKS.github },
  { title: "PlacementConnect", cat: "Salesforce", tech: ["Salesforce CRM", "Custom Objects", "Flow", "Validation Rules", "Reports & Dashboards"],
    summary: "Student placement management system built on the Salesforce platform.",
    points: ["Manages students, companies, job openings, applications, interviews and placement status.", "Custom objects, relationships, validation rules and Flows automate application tracking.", "Reports and dashboards monitor shortlisted candidates and placements."],
    link: LINKS.github },
  { title: "ServiceDesk", cat: "Salesforce", tech: ["Salesforce CRM", "Custom Objects", "Flow", "Validation Rules", "Reports & Dashboards"],
    summary: "Customer support ticket management system on Salesforce.",
    points: ["Manages support cases, priorities, agents and ticket status.", "Salesforce Flow automates case assignment.", "Dashboards track open, resolved and high-priority cases."],
    link: LINKS.github },
  { title: "UCDA AI Architecture Advisor", cat: "Salesforce", tech: ["Salesforce", "Data Cloud / Data 360", "Generative AI", "Data Modeling"],
    summary: "Salesforce-oriented customer data architecture advisor powered by Generative AI.",
    points: ["Explores Customer 360, Data Cloud / Data 360, data modeling and governance concepts.", "Applies Generative AI to support architecture recommendations."],
    link: LINKS.github },
  { title: "ROS Differential Drive Bot", cat: "Robotics", tech: ["ROS", "Gazebo", "Raspberry Pi", "RPLIDAR"],
    summary: "ROS-based differential-drive robot for mapping and navigation.",
    points: ["Gazebo simulation, teleoperation control and sensor integration.", "Validated software across simulation and hardware, resolving 12 integration issues before deployment."],
    link: LINKS.github },
];

const JOBS: Job[] = [
  { role: "Android Developer Intern", org: "MountReach Pvt. Ltd.", place: "Remote · Amravati, Maharashtra", when: "Nov 2024 – Jan 2025",
    points: ["Developed and implemented 8 Android application features in Java and Android Studio within Scrum-based sprints.", "Integrated 10 REST API endpoints to power core app functionality.", "Diagnosed and resolved 15 performance issues, testing across 5 devices."] },
  { role: "Web Developer Intern", org: "Hindavi Softech Pvt. Ltd.", place: "Jalna, Maharashtra", when: "May 2024 – Jul 2024",
    points: ["Built and tested 6 client-facing web features in Python and JavaScript.", "Worked with a team of 5 developers using Git and peer code review in Agile sprints.", "Contributed to debugging, testing and improvement of web applications."] },
];

const SKILLS: [string, string[]][] = [
  ["Languages", ["Java", "Python", "C++", "JavaScript", "TypeScript", "SQL"]],
  ["Web & Backend", ["React.js", "Angular", "Node.js", "Flask", "REST APIs", "HTML5", "CSS3", "Bootstrap", "Vite"]],
  ["Generative AI", ["LLM Integration", "AI Agents", "LangChain", "FAISS", "NLP", "Prompt Engineering", "Gemini API", "Google AI Studio"]],
  ["Salesforce", ["Agentforce", "Prompt Builder", "Salesforce Flow", "Custom Objects", "Validation Rules", "Reports & Dashboards", "Lightning Experience", "Data Cloud (concepts)"]],
  ["Databases", ["MySQL", "MongoDB", "Firebase Firestore"]],
  ["Tools & Robotics", ["Git", "GitHub", "Docker", "Linux", "VS Code", "Android Studio", "Jupyter", "Google Colab", "ROS", "Gazebo"]],
  ["Core CS", ["Data Structures & Algorithms", "OOP", "DBMS", "Operating Systems", "Computer Networks", "Agile/Scrum", "SDLC", "Unit Testing"]],
];

const CERTS = ["Salesforce Certified Agentforce Specialist — Salesforce", "SQL (Advanced) — HackerRank", "C, C++, Linux — Infosys", "Advanced Java — Hindavi Softech", "Python 3 — MountReach"];
const WINS = [
  ["Runner-Up", "NextTuring CP Individuals 2026 — Newton School of Technology, Bengaluru"],
  ["Winner", "Full Stack Development Project Competition (1st rank, solo) — Government Polytechnic, Ambad"],
  ["300+", "problems solved on LeetCode"],
  ["10+", "national-level hackathons and coding competitions"],
  ["2", "national-level hackathons organized as Organizer/Head"],
  ["Best Organizer", "Best Event Management Organizer for an event with 1,000 participants"],
];

function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); io.disconnect(); } }, { threshold: 0.12 });
    io.observe(el); return () => io.disconnect();
  }, []);
  return <div ref={ref} style={{ transitionDelay: delay + "ms" }} className={"reveal " + (on ? "in " : "") + className}>{children}</div>;
}

function Section({ id, eyebrow, title, children }: { id: string; eyebrow: string; title: string; children: ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-6xl px-5 py-20 sm:py-28">
      <Reveal>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">{eyebrow}</p>
        <h2 className="mt-3 font-serif text-3xl font-semibold sm:text-5xl">{title}</h2>
      </Reveal>
      <div className="mt-10 sm:mt-14">{children}</div>
    </section>
  );
}

const Chip = ({ t }: { t: string }) => <span className="rounded-full bg-sand/70 px-3 py-1 text-xs font-medium text-ink">{t}</span>;

function saveResume(kind: "general" | "salesforce") {
  const a = document.createElement("a");
  a.href = BASE + PDFS[kind];
  a.download = PDFS[kind];
  document.body.appendChild(a); a.click(); a.remove();
}

function Nav({ dark, toggle }: { dark: boolean; toggle: () => void }) {
  const [open, setOpen] = useState(false);
  const items = ["About", "Skills", "Experience", "Projects", "Education", "Achievements", "Contact"];
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-sand/60 bg-bg/75 backdrop-blur-xl" style={{ paddingTop: "env(safe-area-inset-top,0px)" }}>
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <a href="#top" className="font-serif text-lg font-semibold">Harshada<span className="text-accent">.</span></a>
        <ul className="hidden items-center gap-7 text-sm text-muted md:flex">
          {items.map(i => <li key={i}><a className="transition hover:text-ink" href={"#" + i.toLowerCase()}>{i}</a></li>)}
        </ul>
        <div className="flex items-center gap-2">
          <button onClick={toggle} aria-label="Toggle theme" className="h-9 w-9 rounded-full border border-sand text-sm transition hover:bg-sand/60">{dark ? "☀" : "☾"}</button>
          <button onClick={() => setOpen(!open)} aria-label="Menu" className="h-9 w-9 rounded-full border border-sand md:hidden">{open ? "✕" : "☰"}</button>
        </div>
      </nav>
      {open && <ul className="border-t border-sand/60 bg-bg px-5 py-3 md:hidden">{items.map(i => <li key={i}><a onClick={() => setOpen(false)} className="block py-2 text-sm" href={"#" + i.toLowerCase()}>{i}</a></li>)}</ul>}
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden px-5 pb-16 pt-32 sm:pt-40">
      <div className="blob -left-20 top-10 h-72 w-72 bg-sand" />
      <div className="blob -right-10 top-40 h-80 w-80 bg-accent/30" style={{ animationDelay: "-6s" }} />
      <div className="relative mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-[1.3fr_1fr]">
        <div>
          <Reveal><p className="inline-flex items-center gap-2 rounded-full border border-sand bg-surface/70 px-4 py-1.5 text-xs font-medium text-muted"><span className="h-2 w-2 rounded-full bg-accent" />Salesforce Certified Agentforce Specialist</p></Reveal>
          <Reveal delay={100}><h1 className="mt-6 font-serif text-5xl font-semibold leading-[1.05] sm:text-7xl">Harshada<br />Jadhav</h1></Reveal>
          <Reveal delay={200}><p className="mt-5 text-lg font-medium text-accent sm:text-xl">Full-Stack & Generative AI Developer</p></Reveal>
          <Reveal delay={300}><p className="mt-5 max-w-xl leading-relaxed text-muted">Final-year Computer Technology student at YCCE, Nagpur, building web applications, Android apps, Salesforce solutions and LLM-powered AI-agent systems. Seeking an entry-level software or Salesforce AI role.</p></Reveal>
          <Reveal delay={400}>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#projects" className="rounded-full bg-ink px-6 py-3 text-sm font-semibold text-bg transition hover:scale-105">View Projects</a>
              <button onClick={() => saveResume("general")} className="rounded-full border border-ink/30 px-6 py-3 text-sm font-semibold transition hover:bg-sand/60">Download Resume ↓</button>
              <a href="#contact" className="rounded-full px-6 py-3 text-sm font-semibold text-accent transition hover:underline">Contact →</a>
            </div>
          </Reveal>
        </div>
        <Reveal delay={200} className="mx-auto w-full max-w-sm">
          <div className="relative">
            <div className="absolute -inset-3 rounded-[2.5rem] bg-gradient-to-br from-accent/40 to-sand" />
            <img src={PHOTO} alt="Portrait of Harshada Jadhav" className="relative aspect-[4/5] w-full rounded-[2rem] object-cover object-top shadow-2xl" />
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Stats() {
  const s = [["300+", "LeetCode problems"], ["10+", "Hackathons"], ["2", "Hackathons organized"], ["7.57", "Current SGPA"]];
  return (
    <div className="mx-auto grid max-w-6xl grid-cols-2 gap-4 px-5 sm:grid-cols-4">
      {s.map(([n, l], i) => (
        <Reveal key={l} delay={i * 80}><div className="rounded-3xl bg-surface p-6 text-center shadow-sm"><p className="font-serif text-4xl font-semibold text-accent">{n}</p><p className="mt-1 text-xs text-muted">{l}</p></div></Reveal>
      ))}
    </div>
  );
}

function ProjectCard({ p }: { p: Project }) {
  const [open, setOpen] = useState(false);
  return (
    <article className="card flex flex-col rounded-3xl border border-sand/70 bg-surface p-6">
      <div className="flex items-start justify-between gap-3">
        <h3 className="font-serif text-xl font-semibold">{p.title}</h3>
        <span className="shrink-0 rounded-full bg-accent/15 px-3 py-1 text-[11px] font-semibold text-accent">{p.cat}</span>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-muted">{p.summary}</p>
      <div className="mt-4 flex flex-wrap gap-1.5">{p.tech.map(t => <Chip key={t} t={t} />)}</div>
      <div className={"expand " + (open ? "open" : "")}><div><ul className="mt-4 list-disc space-y-1.5 pl-5 text-sm text-muted">{p.points.map(x => <li key={x}>{x}</li>)}</ul></div></div>
      <div className="mt-auto flex items-center justify-between pt-5 text-sm font-semibold">
        <button onClick={() => setOpen(!open)} aria-expanded={open} className="text-accent hover:underline">{open ? "Show less" : "Details"}</button>
        <a href={p.link} target="_blank" rel="noopener noreferrer" className="hover:text-accent">GitHub ↗</a>
      </div>
    </article>
  );
}

function Projects() {
  const cats = ["All", "AI", "Salesforce", "Robotics"]; const [f, setF] = useState("All");
  return (
    <Section id="projects" eyebrow="Selected work" title="Projects">
      <div className="mb-8 flex flex-wrap gap-2">
        {cats.map(c => <button key={c} onClick={() => setF(c)} className={"rounded-full px-5 py-2 text-sm font-medium transition " + (f === c ? "bg-ink text-bg" : "bg-sand/60 hover:bg-sand")}>{c}</button>)}
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {PROJECTS.filter(p => f === "All" || p.cat === f).map(p => <ProjectCard key={p.title} p={p} />)}
      </div>
    </Section>
  );
}

function Contact() {
  const [n, setN] = useState(""); const [e, setE] = useState(""); const [m, setM] = useState("");
  const send = () => {
    const body = m + "\n\n— " + n + (e ? " (" + e + ")" : "");
    window.location.href = "mailto:" + LINKS.email + "?subject=" + encodeURIComponent("Portfolio enquiry from " + (n || "a visitor")) + "&body=" + encodeURIComponent(body);
  };
  const inp = "w-full rounded-2xl border border-sand bg-bg px-4 py-3 text-sm outline-none transition focus:border-accent";
  return (
    <Section id="contact" eyebrow="Get in touch" title="Let's work together">
      <div className="grid gap-8 md:grid-cols-2">
        <Reveal>
          <p className="max-w-md leading-relaxed text-muted">Open to entry-level software engineering and Salesforce / Salesforce AI opportunities. Reach out by email, phone or through the links below.</p>
          <ul className="mt-6 space-y-3 text-sm">
            <li><a className="hover:text-accent" href={"mailto:" + LINKS.email}>✉ {LINKS.email}</a></li>
            <li><a className="hover:text-accent" href={"tel:" + LINKS.phone}>☎ {LINKS.phone}</a></li>
            <li>⌖ Nagpur, Maharashtra, India</li>
          </ul>
          <div className="mt-6 flex flex-wrap gap-3 text-sm font-semibold">
            {[["GitHub", LINKS.github], ["LinkedIn", "https://" + LINKS.linkedin], ["YouTube", LINKS.youtube]].map(([l, h]) => <a key={l} href={h} target="_blank" rel="noopener noreferrer" className="rounded-full border border-sand px-5 py-2 transition hover:bg-sand/60">{l} ↗</a>)}
          </div>
          <div className="mt-6 flex flex-wrap gap-3 text-sm font-semibold">
            <button onClick={() => saveResume("general")} className="rounded-full bg-ink px-5 py-2.5 text-bg transition hover:scale-105">Resume (General) ↓</button>
            <button onClick={() => saveResume("salesforce")} className="rounded-full bg-accent px-5 py-2.5 text-bg transition hover:scale-105">Resume (Salesforce) ↓</button>
          </div>
        </Reveal>
        <Reveal delay={120}>
          <div className="space-y-4 rounded-3xl bg-surface p-6 shadow-sm sm:p-8">
            <input className={inp} placeholder="Your name" value={n} onChange={ev => setN(ev.target.value)} aria-label="Your name" />
            <input className={inp} type="email" placeholder="Your email" value={e} onChange={ev => setE(ev.target.value)} aria-label="Your email" />
            <textarea className={inp} rows={5} placeholder="Your message" value={m} onChange={ev => setM(ev.target.value)} aria-label="Your message" />
            <button onClick={send} disabled={!m.trim()} className="w-full rounded-full bg-ink py-3 text-sm font-semibold text-bg transition hover:opacity-90 disabled:opacity-40">Send via email</button>
            <p className="text-center text-xs text-muted">Opens your email app with the message ready to send.</p>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}

function App() {
  const [dark, setDark] = useState(() => window.matchMedia("(prefers-color-scheme: dark)").matches);
  useEffect(() => { document.documentElement.setAttribute("data-theme", dark ? "dark" : "light"); }, [dark]);
  return (
    <>
      <Nav dark={dark} toggle={() => setDark(!dark)} />
      <main>
        <Hero />
        <Stats />
        <Section id="about" eyebrow="About" title="Building across web, AI & CRM">
          <Reveal><p className="max-w-3xl text-lg leading-relaxed text-muted">I'm a Computer Technology undergraduate graduating in 2027 and a Salesforce Certified Agentforce Specialist with software development internship experience and hands-on Generative AI and AI-agent projects. My foundation spans Java, Python, SQL, REST APIs and web technologies, alongside Salesforce CRM, Agentforce, Data Cloud / Data 360 and customer data concepts.</p></Reveal>
        </Section>
        <Section id="skills" eyebrow="Toolkit" title="Skills">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {SKILLS.map(([g, list], i) => (
              <Reveal key={g} delay={i * 60}><div className="h-full rounded-3xl bg-surface p-6"><h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-accent">{g}</h3><div className="flex flex-wrap gap-1.5">{list.map(s => <Chip key={s} t={s} />)}</div></div></Reveal>
            ))}
          </div>
        </Section>
        <Section id="experience" eyebrow="Internships" title="Experience">
          <div className="relative space-y-6 border-l border-sand pl-6 sm:pl-10">
            {JOBS.map((j, i) => (
              <Reveal key={j.role} delay={i * 100}>
                <div className="relative rounded-3xl bg-surface p-6 sm:p-8">
                  <span className="absolute -left-[33px] top-9 h-3 w-3 rounded-full bg-accent ring-4 ring-bg sm:-left-[49px]" />
                  <p className="text-xs font-semibold uppercase tracking-wider text-accent">{j.when}</p>
                  <h3 className="mt-2 font-serif text-xl font-semibold">{j.role}</h3>
                  <p className="text-sm text-muted">{j.org} · {j.place}</p>
                  <ul className="mt-4 list-disc space-y-1.5 pl-5 text-sm text-muted">{j.points.map(p => <li key={p}>{p}</li>)}</ul>
                </div>
              </Reveal>
            ))}
          </div>
        </Section>
        <Projects />
        <Section id="education" eyebrow="Background" title="Education & Certifications">
          <div className="grid gap-5 md:grid-cols-2">
            <Reveal><div className="h-full rounded-3xl bg-surface p-6 sm:p-8"><p className="text-xs font-semibold uppercase tracking-wider text-accent">Sep 2024 – May 2027 (Expected)</p><h3 className="mt-2 font-serif text-xl font-semibold">B.E., Computer Technology</h3><p className="text-sm text-muted">Yeshwantrao Chavan College of Engineering (YCCE), Nagpur</p><p className="mt-3 text-sm">SGPA: 7.57</p></div></Reveal>
            <Reveal delay={100}><div className="h-full rounded-3xl bg-surface p-6 sm:p-8"><p className="text-xs font-semibold uppercase tracking-wider text-accent">Dec 2021 – May 2024</p><h3 className="mt-2 font-serif text-xl font-semibold">Diploma in Information Technology</h3><p className="text-sm text-muted">Government Polytechnic, Ambad, Maharashtra</p><p className="mt-3 text-sm">Percentage: 72.88%</p></div></Reveal>
          </div>
          <Reveal delay={150}><div className="mt-5 rounded-3xl bg-surface p-6 sm:p-8"><h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-accent">Certifications</h3><ul className="grid gap-2 text-sm sm:grid-cols-2">{CERTS.map(c => <li key={c} className="flex gap-2"><span className="text-accent">✓</span>{c}</li>)}</ul></div></Reveal>
        </Section>
        <Section id="achievements" eyebrow="Recognition" title="Achievements">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {WINS.map(([h, t], i) => <Reveal key={t} delay={i * 60}><div className="card h-full rounded-3xl bg-surface p-6"><p className="font-serif text-2xl font-semibold text-accent">{h}</p><p className="mt-2 text-sm text-muted">{t}</p></div></Reveal>)}
          </div>
        </Section>
        <Contact />
      </main>
      <footer className="border-t border-sand/60 px-5 py-8 text-center text-xs text-muted">© {new Date().getFullYear()} Harshada Jadhav · Nagpur, India</footer>
    </>
  );
}

export default App;
